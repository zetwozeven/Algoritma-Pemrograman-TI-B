#JAWABAN SOAL 1

print("Masukkan Angka Favoritmu:")

angka = input()

print("Angka Favoritmu adalah", angka )




