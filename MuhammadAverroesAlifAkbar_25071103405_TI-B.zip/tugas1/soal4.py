#JAWABAN SOAL 4

print("Masukkan angka:")


num = int(input())

for x in range(num):
  print(x)

y = sum(range(num))

print("Jumlah seluruh angka adalah " , (y))  
  
