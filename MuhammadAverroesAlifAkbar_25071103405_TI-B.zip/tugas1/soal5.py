#JAWABAN SOAL 5


a = int(input("Masukkan angka pertama:"))
b = int(input("Masukkan angka kedua:"))


def jumlah():
  print("A ditambah B ada", a + b)

def kurang():
  print("A dikurang B ada", a - b)

def kali():
  print("A dikali B ada", a * b)

def bagi():
  print("A dibagi B ada", a / b)


jumlah()
kurang()
kali()
bagi()





