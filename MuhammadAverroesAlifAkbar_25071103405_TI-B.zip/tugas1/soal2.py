#JAWABAN SOAL 2

a = float(input("Masukkan nilai a: "))
b = float(input("Masukkan nilai b: "))

print("a + b =", a + b)
print("a - b =", a - b)
print("a * b =", a * b)
print("a / b =", a / b)